# Rapport — Analyse des journaux du pare-feu (5 au 11 octobre 2026)

## Résumé
Après nettoyage (60 doublons supprimés, 166 valeurs `bytes_sent` manquantes remplacées par la médiane, protocoles mis en majuscules), le journal contient **5 440 connexions**. Le trafic est dominé par HTTPS (port 443), HTTP (80) et DNS (53), et **13,57 %** des connexions sont bloquées (`DENY`). Deux comportements anormaux ressortent nettement : un **scan de ports** mené depuis un PC (192.168.1.99) et une **exfiltration massive de données** depuis une caméra IoT (192.168.1.11). Le trafic Telnet, RDP et SSH est également bloqué ou exposé de façon préoccupante.

## Comportements suspects

### 1. Scan de ports depuis 192.168.1.99
- Cette IP a contacté **328 ports distincts**, contre 8 pour les autres machines (figure `ports_distincts_par_ip.png`).
- Toute l'activité a lieu le **8 octobre entre 00h00 et 00h15**, vers une seule cible (10.0.0.5), avec **400 connexions dont 383 bloquées** (96 %).
- C'est la signature d'un balayage de ports (reconnaissance) : un PC compromis ou un utilisateur malveillant.
- Ce scan explique le pic d'activité du 8 octobre (1 137 connexions contre ~700 les autres jours).

### 2. Exfiltration depuis la caméra IoT 192.168.1.11
- Cette IP a envoyé **259,9 Mo**, soit environ **95 %** du volume total du réseau (274,6 Mo), alors que la médiane d'une connexion est d'environ 1,7 Ko (figures `octets_par_ip.png` et `octets_par_appareil.png`).
- **38 transferts de plus de 5 Mo** (≈ 259,5 Mo) ont eu lieu **le 10 octobre**, répartis sur toute la journée, tous vers **8.8.8.8 sur le port 8080**, et tous **autorisés** (`ALLOW`).
- Une caméra n'a aucune raison d'envoyer de tels volumes vers l'extérieur sur un port web alternatif : il s'agit probablement d'une caméra compromise qui exfiltre des données.

## Autres observations
- Telnet (port 23), protocole non chiffré, reçoit 100 tentatives depuis 29 sources, dont 74 bloquées mais **26 autorisées**.
- Le RDP (3389) est sollicité 111 fois, dont 30 autorisées ; le SSH (22) 316 fois.

## Recommandations
1. **Fermer Telnet** (port 23) sur tout le réseau et le remplacer par SSH avec authentification par clé.
2. **Segmenter les objets IoT** dans un VLAN dédié, sans accès direct aux serveurs internes et avec une politique de sortie « tout interdit sauf besoin explicite » (par exemple uniquement le broker MQTT).
3. **Bloquer le trafic sortant de 192.168.1.11** (isoler la caméra), changer ses identifiants et mettre à jour son firmware ; filtrer le port 8080 en sortie et vérifier la destination des flux.
4. **Isoler et inspecter le poste 192.168.1.99** (analyse antivirus/EDR, vérification des comptes utilisés), et ajouter une règle de détection de scan (alerte au-delà de N ports distincts par minute depuis une même source).
5. **Restreindre RDP et SSH** aux seules adresses d'administration (liste blanche ou accès via VPN) et mettre en place des alertes sur les volumes sortants anormaux.
