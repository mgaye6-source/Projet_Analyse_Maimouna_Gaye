"""Analyse des journaux d'un pare-feu (Projet 1).

Usage : python analyse.py
Lit data/logs_reseau.csv, nettoie les données, calcule les résultats,
enregistre les figures dans figures/ et écrit resultats.json.
"""
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # pas besoin d'écran pour enregistrer les figures
import matplotlib.pyplot as plt
import pandas as pd

CSV = Path("data/logs_reseau.csv")
FIG_DIR = Path("figures")
SORTIE = Path("resultats.json")


def nettoyer(df):
    """Nettoyage demandé : doublons, casse du protocole, médiane des octets."""
    df = df.drop_duplicates().copy()
    df["protocol"] = df["protocol"].str.upper()
    mediane = df["bytes_sent"].median()  # calculée après suppression des doublons
    df["bytes_sent"] = df["bytes_sent"].fillna(mediane)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    return df


def calculer_resultats(df):
    return {
        "nb_lignes_apres_nettoyage": int(len(df)),
        "top_port": int(df["dst_port"].value_counts().idxmax()),
        "taux_deny_pct": round(float((df["action"] == "DENY").mean() * 100), 2),
        "ip_scanner": str(df.groupby("src_ip")["dst_port"].nunique().idxmax()),
        "ip_exfiltration": str(df.groupby("src_ip")["bytes_sent"].sum().idxmax()),
    }


def sauver(fig, nom):
    fig.tight_layout()
    fig.savefig(FIG_DIR / nom, dpi=120)
    plt.close(fig)


def faire_figures(df, res):
    FIG_DIR.mkdir(exist_ok=True)

    # 1. Top 10 des ports de destination
    fig, ax = plt.subplots(figsize=(8, 5))
    top = df["dst_port"].value_counts().head(10)
    ax.bar(top.index.astype(str), top.values, color="steelblue")
    ax.set_title("Top 10 des ports de destination")
    ax.set_xlabel("Port de destination")
    ax.set_ylabel("Nombre de connexions")
    sauver(fig, "top_ports.png")

    # 2. Répartition ALLOW / DENY
    fig, ax = plt.subplots(figsize=(5, 5))
    rep = df["action"].value_counts()
    ax.pie(rep.values, labels=rep.index, autopct="%1.1f%%",
           colors=["seagreen", "indianred"])
    ax.set_title("Répartition ALLOW / DENY")
    sauver(fig, "allow_deny.png")

    # 3. Octets envoyés par type d'appareil
    fig, ax = plt.subplots(figsize=(8, 5))
    vol = df.groupby("device_type")["bytes_sent"].sum() / 1e6
    ax.bar(vol.index, vol.values, color="darkorange")
    ax.set_title("Volume d'octets envoyés par type d'appareil")
    ax.set_xlabel("Type d'appareil")
    ax.set_ylabel("Volume total (Mo)")
    sauver(fig, "octets_par_appareil.png")

    # 4. Connexions par heure de la journée
    fig, ax = plt.subplots(figsize=(9, 5))
    par_heure = df.groupby(df["timestamp"].dt.hour).size()
    ax.bar(par_heure.index, par_heure.values, color="slateblue")
    ax.set_title("Connexions par heure de la journée")
    ax.set_xlabel("Heure (0-23)")
    ax.set_ylabel("Nombre de connexions")
    ax.set_xticks(range(0, 24))
    sauver(fig, "connexions_par_heure.png")

    # 5. Ports distincts contactés par IP source (top 10) -> scanner
    fig, ax = plt.subplots(figsize=(9, 5))
    ports = df.groupby("src_ip")["dst_port"].nunique().nlargest(10)
    ax.barh(ports.index[::-1], ports.values[::-1], color="crimson")
    ax.set_title("Ports distincts contactés par IP source (top 10)")
    ax.set_xlabel("Nombre de ports distincts")
    ax.set_ylabel("IP source")
    sauver(fig, "ports_distincts_par_ip.png")

    # 6. Octets envoyés par IP source (top 10) -> exfiltration
    fig, ax = plt.subplots(figsize=(9, 5))
    octets = (df.groupby("src_ip")["bytes_sent"].sum().nlargest(10) / 1e6)
    ax.barh(octets.index[::-1], octets.values[::-1], color="purple")
    ax.set_title("Volume d'octets envoyés par IP source (top 10)")
    ax.set_xlabel("Volume total (Mo)")
    ax.set_ylabel("IP source")
    sauver(fig, "octets_par_ip.png")


def main():
    df = pd.read_csv(CSV)
    df = nettoyer(df)
    res = calculer_resultats(df)
    SORTIE.write_text(json.dumps(res, indent=2, ensure_ascii=False), encoding="utf-8")
    faire_figures(df, res)
    print(json.dumps(res, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
